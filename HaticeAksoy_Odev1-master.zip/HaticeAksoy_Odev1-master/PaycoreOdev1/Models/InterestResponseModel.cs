﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaycoreOdev1.Models
{
    public class InterestResponseModel
    {
        public double InterestAmount { get; set; }
        public double TotalBalance { get; set; }
    }
}
