# HaticeAksoy_Odev1

Hafta-1 Ödevindeki Bileşik Faiz Hesaplaması için bir api projesidir. 


- İstekler aşağıdaki ekran fotoğrafları içerisinde yer almaktadır. 
# Swagger ve Postman Ekran Görüntüleri: 



![api1](https://user-images.githubusercontent.com/42001247/184471380-a18cbcb2-8482-40c8-a71f-cb7746b9ec10.png)

![api2](https://user-images.githubusercontent.com/42001247/184471421-a891c52c-21c5-4e58-b5da-f717106608e2.png)



- Girilen Parametreler iiçerisinde Negatif bir değer olması durumunda BadRequest sonucu dönmektedir. 
# Postman Ekran Görüntüsü.

![api3](https://user-images.githubusercontent.com/42001247/184471443-33d3d73c-93c8-469c-aed5-55e574f39d7a.png)

